================================================================================
CabsOnline - Web Development Assignment 3
Author: Aaron Taula - 15905800
================================================================================

FILES IN THIS SYSTEM
--------------------
booking.html     - Passenger taxi booking form
booking.js       - Validation and fetch logic for the booking page
booking.php      - Server-side handler: saves booking to database
admin.html       - Admin search and taxi assignment page
admin.js         - Search and assign logic for the admin page
admin.php        - Server-side handler: searches and assigns bookings
mysqlcommand.txt - SQL command to create the bookings table
readme.txt       - This file

================================================================================
HOW TO SET UP
================================================================================

1. CREATE THE DATABASE TABLE
   - Log into phpMyAdmin on webdev.aut.ac.nz
   - Select your database (cdt6246)
   - Click the SQL tab
   - Paste the contents of mysqlcommand.txt and click Go

2. CHECK settings.php EXISTS
   - The PHP files load DB credentials from:
     ../../files/settings.php  (two folders above htdocs)
   - This file should define: $dbhost, $dbuser, $dbpass, $dbname
   - If it doesn't exist, ask your lecturer for the correct path

3. UPLOAD FILES
   - Upload all files into: htdocs/assign/
   - No subfolders - all files go directly in the assign folder

================================================================================
HOW TO USE
================================================================================

BOOKING PAGE
  URL: http://webdev.aut.ac.nz/~cdt6246/assign/booking.html
  - Fill in the required fields and click Book Taxi
  - A confirmation with booking reference number will appear on the page

ADMIN PAGE
  URL: http://webdev.aut.ac.nz/~cdt6246/assign/admin.html
  - Leave the search box empty and click Search Bookings to see all
    unassigned bookings with a pickup in the next 2 hours
  - Type a booking reference (e.g. BRN00001) to find a specific booking
  - Click Assign on any row to assign a taxi to that booking

================================================================================
