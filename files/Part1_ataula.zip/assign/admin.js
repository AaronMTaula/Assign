/*
  File: admin.js
  Author: Aaron Taula - 15905800
  Description: Handles search and taxi assignment on the admin page.

  Functions:
    searchBookings()        - validates input and fetches booking results from admin.php
    displayResults(data)    - builds and shows the results table on the page
    assignTaxi(brn, btn)    - sends an assign request for a booking to admin.php
*/

// searchBookings - called when the Search Bookings button is clicked
// If bsearch has a value, checks the format then searches for that BRN
// If bsearch is empty, fetches all unassigned bookings in the next 2 hours
async function searchBookings() {

  // Clear previous errors and results
  document.getElementById('err-bsearch').textContent = '';
  document.getElementById('resultsContainer').innerHTML = '';
  document.getElementById('assignMessage').textContent = '';

  var searchVal = document.getElementById('bsearch').value.trim();

  // If user typed something, check it matches the BRN format BRNnnnnn
  if (searchVal !== '') {
    if (!/^BRN\d{5}$/.test(searchVal)) {
      document.getElementById('err-bsearch').textContent =
        'Invalid format. Must be like BRN00001 (BRN + 5 digits).';
      return;
    }
  }

  // Send search request to admin.php
  var response = await fetch('admin.php?action=search&bsearch=' + encodeURIComponent(searchVal));
  var result   = await response.json();

  if (result.success) {
    displayResults(result.bookings);
  } else {
    document.getElementById('resultsContainer').innerHTML =
      '<p>' + result.message + '</p>';
  }
}

// displayResults - builds an HTML table from the bookings array
// Shows a message if no bookings were found
function displayResults(bookings) {
  var container = document.getElementById('resultsContainer');

  if (bookings.length === 0) {
    container.innerHTML = '<p>No bookings found.</p>';
    return;
  }

  // Build the table header
  var html = '<table>';
  html += '<tr>';
  html += '<th>Booking Reference Number</th>';
  html += '<th>Customer Name</th>';
  html += '<th>Phone</th>';
  html += '<th>Pickup Suburb</th>';
  html += '<th>Destination Suburb</th>';
  html += '<th>Pickup Date and Time</th>';
  html += '<th>Status</th>';
  html += '<th>Assign</th>';
  html += '</tr>';

  // Build one row per booking
  for (var i = 0; i < bookings.length; i++) {
    var b = bookings[i];

    // Format date from YYYY-MM-DD to DD/MM/YYYY
    var dateParts = b.pickup_date.split('-');
    var displayDate = dateParts[2] + '/' + dateParts[1] + '/' + dateParts[0];

    // Show only HH:MM from the time
    var displayTime = b.pickup_time.substring(0, 5);

    // Disable assign button if already assigned
    var isAssigned  = (b.status === 'assigned');
    var btnDisabled = isAssigned ? 'disabled' : '';
    var btnLabel    = isAssigned ? 'Assigned' : 'Assign';

    html += '<tr id="row-' + b.booking_ref + '">';
    html += '<td>' + b.booking_ref + '</td>';
    html += '<td>' + b.cname + '</td>';
    html += '<td>' + b.phone + '</td>';
    html += '<td>' + (b.sbname  || '-') + '</td>';
    html += '<td>' + (b.dsbname || '-') + '</td>';
    html += '<td>' + displayDate + ' ' + displayTime + '</td>';
    html += '<td id="status-' + b.booking_ref + '">' + b.status + '</td>';
    html += '<td><button name="Assign" ' + btnDisabled +
            ' onclick="assignTaxi(\'' + b.booking_ref + '\', this)">' +
            btnLabel + '</button></td>';
    html += '</tr>';
  }

  html += '</table>';
  container.innerHTML = html;
}

// assignTaxi - called when an Assign button is clicked
// Sends the BRN to admin.php and updates the page when successful
async function assignTaxi(brn, btn) {

  btn.disabled = true;
  btn.textContent = 'Assigning...';

  var response = await fetch('admin.php?action=assign&brn=' + encodeURIComponent(brn));
  var result   = await response.json();

  if (result.success) {
    // Update the status cell in the table without reloading the page
    document.getElementById('status-' + brn).textContent = 'assigned';
    btn.textContent = 'Assigned';

    // Show confirmation message above the table
    document.getElementById('assignMessage').textContent =
      'Congratulations! Booking request ' + brn + ' has been assigned!';

  } else {
    btn.disabled = false;
    btn.textContent = 'Assign';
    document.getElementById('assignMessage').textContent =
      'Error: ' + result.message;
  }
}
